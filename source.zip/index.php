<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41b5e0f5d             |
    |_______________________________________|
*/
 use Pmpr\Module\Jalali\Jalali; Jalali::symcgieuakksimmu();
