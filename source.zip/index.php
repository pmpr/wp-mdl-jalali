<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d8b63847             |
    |_______________________________________|
*/
 use Pmpr\Module\Jalali\Jalali; Jalali::symcgieuakksimmu();
