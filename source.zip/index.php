<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ac43afa1             |
    |_______________________________________|
*/
 use Pmpr\Module\Jalali\Jalali; Jalali::symcgieuakksimmu();
