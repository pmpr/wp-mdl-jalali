<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692c4d3de3ecb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin\Dokan; use Pmpr\Module\Jalali\Container; class Checkout extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('wp', [$this, 'gosmqcmmomkqwmis']); $this->waqewsckuayqguos('before_enqueue_frontend_assets', [$this, 'enqueue']); } public function gosmqcmmomkqwmis() { if ($this->uwkmaywceaaaigwo()->wikusamwomuogoau()->gqoskmoekogyqwsc()) { $this->ewcsyqaaigkicgse('enqueue_datepicker_assets'); } } public function enqueue() { if ($this->uwkmaywceaaaigwo()->wikusamwomuogoau()->gqoskmoekogyqwsc()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->awgyqswkqywwmkye($this, 'dokan-checkout', 'dokan-checkout.css'))->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, 'dokan-checkout', 'dokan-checkout.js')->okawmmwsiuauwsiu()); } } }
