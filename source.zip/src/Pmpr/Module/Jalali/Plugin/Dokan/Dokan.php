<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             693b5aa4302db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin\Dokan; use Pmpr\Module\Jalali\Container; class Dokan extends Container { public function mameiwsayuyquoeq() { Checkout::symcgieuakksimmu(); SellerDashboard::symcgieuakksimmu(); } }
