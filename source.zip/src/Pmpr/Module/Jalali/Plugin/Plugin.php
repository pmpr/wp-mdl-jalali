<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8eda2905             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\151\x6e\163\137\x6c\x6f\x61\x64\145\144", [$this, "\151\x63\x77\x63\147\155\x63\157\x69\x6d\x71\145\151\147\x79\145"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto ogsaaqsaogcqiouy; } Woocommerce::symcgieuakksimmu(); ogsaaqsaogcqiouy: } }
