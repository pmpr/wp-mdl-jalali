<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400db8b3ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\147\151\156\163\x5f\154\157\141\144\145\144", [$this, "\x69\143\167\143\147\155\143\x6f\x69\x6d\x71\x65\x69\147\x79\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto gcckqucukawcasgk; } Woocommerce::symcgieuakksimmu(); gcckqucukawcasgk: } }
