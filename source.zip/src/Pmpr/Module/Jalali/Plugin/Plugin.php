<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43ae262ae9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\x75\147\x69\156\163\137\154\157\141\144\x65\x64", [$this, "\151\x63\167\x63\147\x6d\143\x6f\x69\155\161\145\151\x67\171\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto ikqqskkqqwmwssoo; } Woocommerce::symcgieuakksimmu(); ikqqskkqqwmwssoo: } }
