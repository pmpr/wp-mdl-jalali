<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41b5e0f5d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\154\x75\147\x69\156\163\137\x6c\157\x61\144\x65\x64", [$this, "\151\143\167\x63\x67\x6d\143\x6f\151\155\161\145\x69\147\x79\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto eqkauqciwewmgeoi; } Woocommerce::symcgieuakksimmu(); eqkauqciwewmgeoi: } }
