<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65ff5931398d5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6c\x75\x67\x69\156\163\x5f\154\x6f\x61\144\x65\144", [$this, "\151\143\167\x63\147\x6d\x63\x6f\151\155\161\x65\151\147\171\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto oouoqimaaqcmccay; } Woocommerce::symcgieuakksimmu(); oouoqimaaqcmccay: } }
