<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8880ed8c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\147\x69\156\x73\137\154\157\141\x64\x65\x64", [$this, "\151\143\167\143\x67\155\x63\157\151\155\161\x65\x69\x67\171\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto siqagquguiemuoku; } Woocommerce::symcgieuakksimmu(); siqagquguiemuoku: } }
