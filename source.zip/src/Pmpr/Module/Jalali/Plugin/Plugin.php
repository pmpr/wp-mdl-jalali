<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d4c77962             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\165\x67\x69\156\163\x5f\x6c\x6f\x61\x64\x65\144", [$this, "\x69\143\x77\x63\147\x6d\x63\x6f\151\155\x71\145\x69\147\x79\145"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto cuumeogeomowqisc; } Woocommerce::symcgieuakksimmu(); cuumeogeomowqisc: } }
