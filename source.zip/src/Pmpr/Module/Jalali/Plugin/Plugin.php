<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec695afdf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\x67\151\156\163\x5f\x6c\x6f\141\x64\145\144", [$this, "\x69\x63\167\143\x67\155\x63\x6f\151\155\161\x65\x69\147\171\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto asmecuqiyyswueqe; } Woocommerce::symcgieuakksimmu(); asmecuqiyyswueqe: } }
