<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687080c4527c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6c\x75\147\151\x6e\163\137\x6c\157\141\144\145\144", [$this, "\x69\x63\x77\143\x67\x6d\143\x6f\151\x6d\x71\x65\151\147\x79\145"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto gcckqucukawcasgk; } Woocommerce::symcgieuakksimmu(); gcckqucukawcasgk: } }
