<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f09e8afb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; class Plugin extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\154\165\147\151\x6e\163\137\x6c\157\141\x64\x65\144", [$this, "\151\x63\167\143\147\x6d\x63\157\151\155\x71\x65\151\147\x79\x65"]); } public function icwcgmcoimqeigye() { if (!$this->caokeucsksukesyo()->wikusamwomuogoau()->ggocakcisguuokai()) { goto cuumeogeomowqisc; } Woocommerce::symcgieuakksimmu(); cuumeogeomowqisc: } }
