<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90ab22b6a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; use Pmpr\Module\Jalali\Container; abstract class Common extends Container { }
