<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400db8b3ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; use Pmpr\Module\Jalali\Container; abstract class Common extends Container { }
