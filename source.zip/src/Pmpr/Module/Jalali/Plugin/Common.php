<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d4c77962             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin; use Pmpr\Module\Jalali\Container; abstract class Common extends Container { }
