<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d8b63847             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Jalali\Plugin\Woocommerce; use Pmpr\Module\Jalali\Container; class Backend extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos('before_enqueue_backend_assets', [$this, 'enqueue']); } public function enqueue() { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $this->ewcsyqaaigkicgse('enqueue_datepicker_assets'); $meakksicouekcgoe->qeqgammgesiwiysc($meakksicouekcgoe->awgyqswkqywwmkye($this, 'woocommerce-backend', 'woocommerce-backend.css'))->qeqgammgesiwiysc($meakksicouekcgoe->owygwqwawqoiusis($this, 'woocommerce-backend', 'woocommerce-backend.js')->okawmmwsiuauwsiu()); } }
